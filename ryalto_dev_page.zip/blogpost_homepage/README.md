# blogpost_homepage
Vanilla html and CSS for a blogpage 
